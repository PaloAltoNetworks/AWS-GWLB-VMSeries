import boto3
from http.client import HTTPSConnection
import json
import logging
import os
from botocore.config import Config
from boto3.dynamodb.conditions import Key, Attr
from urllib.parse import urlparse
from contextlib import closing
from time import *

logger = logging.getLogger()
logger.setLevel(logging.INFO)


try:
    lambda_root = os.environ.get('LAMBDA_TASK_ROOT')
    models_path = os.path.join(lambda_root, 'models')
    aws_data_path = set(os.environ.get('AWS_DATA_PATH', '').split(os.pathsep))
    aws_data_path.add(models_path)
    os.environ.update({'AWS_DATA_PATH': os.pathsep.join(aws_data_path)})
    gwlb_client = boto3.client(service_name='elbv2-gwlb',config=Config(retries={'max_attempts': 10}))
    gwlbe_client = boto3.client(service_name='ec2-gwlbe',config=Config(retries={'max_attempts': 10}))
except Exception as e:
    logger.error('Error loading service model - %s'%str(e))

events_client = boto3.client('events')
iam = boto3.client('iam')
lambda_client = boto3.client('lambda')

lb_client = boto3.client('elbv2')
sqs_client = boto3.client('sqs')
sts_client = boto3.client('sts')
ec2_client = boto3.client('ec2')
sts_client = boto3.client('sts')
dynamodb = boto3.resource('dynamodb')

def fix_unicode(data):
    """
        Method to convert opaque data from unicode to utf-8
        :param data: Opaque data
        :return: utf-8 encoded data
    """
    if isinstance(data, str):
        return data
    elif isinstance(data, dict):
        data = dict((fix_unicode(k), fix_unicode(data[k])) for k in data)
    elif isinstance(data, list):
        for i in xrange(0, len(data)):
            data[i] = fix_unicode(data[i])

    return data


def fix_subnets(data1):
    """

    :param data1:
    :return:
    """
    data = str(data1)
    data = data.replace("'", "")
    data = data.replace("[", "")
    data = data.replace("]", "")
    return data

def get_ibd_rt_table_name(stack_name, region):
    name = stack_name + '-ibd-' + region
    return name

def create_ibd_rt_table(stack_name,region):
    """

    :param stack_name:
    :param region:
    :return:
    """

    table_name=get_ibd_rt_table_name(stack_name, region)

    try:
        response = dynamodb.create_table(
            AttributeDefinitions=[
                {
                    'AttributeName': 'RouteTableId',
                    'AttributeType': 'S'
                },
                {
                    'AttributeName': 'AssociationId',
                    'AttributeType': 'S'
                },
            ],
            TableName=table_name,
            KeySchema=[
                {
                    'AttributeName': 'RouteTableId',
                    'KeyType': 'HASH'
                },
            ],
            GlobalSecondaryIndexes=[
                {
                    'IndexName': 'AssoIndex',
                    'KeySchema': [
                        {
                            'AttributeName': 'AssociationId',
                            'KeyType': 'HASH'
                        },
                    ],
                    'Projection': {
                        'ProjectionType': 'ALL',
                    },
                    'ProvisionedThroughput': {
                        'ReadCapacityUnits': 10,
                        'WriteCapacityUnits': 10
                    }
                },
            ],
            StreamSpecification={
                'StreamEnabled': True,
                'StreamViewType': 'NEW_AND_OLD_IMAGES'
            },
            ProvisionedThroughput={
                'ReadCapacityUnits': 10,
                'WriteCapacityUnits': 10
            }
        )
        cnt = 0
        while cnt < 10:
            try:
                table = dynamodb.Table(table_name)
                response = table.scan()
                return True
            except Exception as e:
                cnt += 1
                sleep(20)

        else:
            logger.error("[Create DynamoDB Table]: Table didn't stabilized in a long time")
            return False

    except Exception as e:
        logger.exception("[Create DynamoDB Table]: {}".format(e))
        return False

def ibd_rt_table_add_entry(stack_name,region,RtId,AsId):

    """
    :param RtId:
    :return:
    """
    try:
        table_name = get_ibd_rt_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.put_item(
            Item={
                    'RouteTableId': RtId,
                    'AssociationId': AsId
            }
        )
        return True
    except Exception as e:
        logger.exception("[Gwlb Endpoint Table add entry error]: {}".format(e))
        return False

def idb_rt_table_get_entry(stack_name,region):
    ##get all item in the table
    try:
        table_name = get_ibd_rt_table_name(stack_name, region)
        table = dynamodb.Table(table_name)
        response = table.scan()
        return response['Items'][0]

    except Exception as e:
        logger.exception("[Gwlb endpoint Table get entry error]: {}".format(e))
        return None


def get_gwlb_endpoint_table_name(stack_name, region):
    """

    :param stack_name:
    :param region:
    :return:
    """
    name = stack_name + "-gwlb-endpoint-" + region
    return name

def create_gwlb_endpoint_table(stack_name, region):
    """

    :param stack_name:
    :param region:
    :return:
    """
    table_name = get_gwlb_endpoint_table_name(stack_name, region)
    try:
        response = dynamodb.create_table(
            AttributeDefinitions=[
                {
                    'AttributeName': 'GwlbeEndpointId',
                    'AttributeType': 'S'
                },
                {
                    'AttributeName': 'GwlbeEniId',
                    'AttributeType': 'S'

                },
            ],
            TableName=table_name,
            KeySchema=[
                {
                    'AttributeName': 'GwlbeEndpointId',   # partition key
                    'KeyType': 'HASH'
                },
            ],
            GlobalSecondaryIndexes=[
                {
                    'IndexName': 'StateIndex',
                    'KeySchema': [
                        {
                            'AttributeName': 'GwlbeEniId',
                            'KeyType': 'HASH'
                        },

                    ],
                    'Projection': {
                        'ProjectionType': 'ALL',
                    },
                    'ProvisionedThroughput': {
                        'ReadCapacityUnits': 10,
                        'WriteCapacityUnits': 10
                    }
                },
            ],
            StreamSpecification={
                'StreamEnabled': True,
                'StreamViewType': 'NEW_AND_OLD_IMAGES'
            },
            ProvisionedThroughput={
                'ReadCapacityUnits': 10,
                'WriteCapacityUnits': 10
            }
        )
        cnt = 0
        while cnt < 10:
            try:
                table = dynamodb.Table(table_name)
                response = table.scan()
                return True
            except Exception as e:
                logger.info("Creating DynamoDB Table - %s..." % table_name)
                cnt += 1
                sleep(20)
        else:
            logger.exception("[Create DynamoDB Table]: Table didn't stabilized in a long time")
            return False

    except Exception as e:
        logger.exception("[Create DynamoDB Table]: {}".format(e))
        return False


def gwlb_endpoint_table_add_entry(stack_name, region, GwlbeEndpointId, GwlbeEniId):
    """

    :param stack_name:
    :param region:
    :param GwlbeEndpointId:
    :return:
    """
    try:
        table_name=get_gwlb_endpoint_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.put_item(
            Item={
                    'GwlbeEndpointId': GwlbeEndpointId,
                    'GwlbeEniId': GwlbeEniId,
            }
        )
        return True
    except Exception as e:
        logger.exception("[Gwlb Endpoint Table add entry error]: {}".format(e))
        return False

def gwlb_endpoint_table_get_entry(stack_name, region):
    ##get all item in the table
    try:
        table_name = get_gwlb_endpoint_table_name(stack_name, region)
        table = dynamodb.Table(table_name)
        response = table.scan()
        data = response['Items']

        return data

    except Exception as e:
        logger.exception("[Gwlb endpoint Table get entry error]: {}".format(e))
        return None


def delete_table(tablename):
    """

    :param tablename:
    :return:
    """
    dynamodb = boto3.client('dynamodb')
    try:
        dynamodb.delete_table(TableName=tablename)
        return True
    except Exception as e:
        logger.error("[Delete DynamoDB Table]: {}".format(e))
        return False


def get_vpc_endpoint_service_name(vpc_endpoint_service_id):
    """
    Queries aws for the ServiceName attribute of the given vpc endpoint

    Makes a call to describe_vpc_endpoint_services and loops through to find the
    name which contains the given vpc endpoint service id
    """
    response = ec2_client.describe_vpc_endpoint_services()
    names = response['ServiceNames']
    for name in names:
        if vpc_endpoint_service_id in name:
            logger.info('Found vpc endpoint service name: {} for id: {}'.format(name, vpc_endpoint_service_id))
            return name
    logger.error('No vpc endpoint service names match the id: {}'.format(vpc_endpoint_service_id))


def create_vpcpeer_routetable_entry(DestinationCidrBlock, RouteTableId, VpcPeeringConnectionId):
    """
    Method to add vpc peer routes to trust routng table

    :param DestinationCidrBlock
    :param RouteTableId
    :param VpcPeeringConnectionId
    :return: None
    """
    logger.info('Creating route table entries for Dst CIDR in route table :{}, {}'.format(DestinationCidrBlock, RouteTableId))
    try:
        response = ec2_client.create_route(DestinationCidrBlock=DestinationCidrBlock,
                                           RouteTableId=RouteTableId,
                                           VpcPeeringConnectionId=VpcPeeringConnectionId)
        logger.info('[create_vpcpeer_routetable_entry] RESPONSE: {}'.format(response))
    except Exception:
        logger.exception("Adding routes to route table failed for dst CIDR:" + DestinationCidrBlock)


def delete_vpcpeer_routetable_entry(DestinationCidrBlock, RouteTableId):
    """
    Method to delete vpc peer routes to trust routng table

    :param DestinationCidrBlock
    :param RouteTableId
    :param VpcPeeringConnectionId
    :return: None
    """
    logger.info('Deleting route table entries for Dst CIDR in route table: {}, {}'.format(DestinationCidrBlock, RouteTableId))
    try:
        response = ec2_client.delete_route(DestinationCidrBlock=DestinationCidrBlock,
                                           RouteTableId=RouteTableId)
        logger.info('[delete_vpcpeer_routetable_entry] RESPONSE: {}'.format(response))
    except Exception:
        logger.exception('Deleting routes from route table failed for dst CIDR: {}'.format(DestinationCidrBlock))


def get_subnet_info(az_info):
    """
    Method to get information on all subnets in an AZ

    :param az_info:
    :return subnet data:
    """
    print("Az info: {}".format(az_info))
    subnet_ids = list(map(lambda az: az['SUBNET-ID'], az_info))
    subnet_data = ec2_client.describe_subnets(
        SubnetIds=subnet_ids
    )
    print("Subnet data: {}".format(subnet_data))
    return subnet_data


def send_to_queue(data, queue_url, _sts_sqs_client):
    """
    Method to push the DNS Names of the ILB into a SQS Queue
    :param dns_name:
    :return:
    """

    if _sts_sqs_client:
        logger.info("[assumed role sqs resource]: Sending data to queue")

        _sts_sqs_client.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps(data),
            MessageAttributes={
                'panw-fw-nlb-msg': {
                    'StringValue': '1000',
                    'DataType': 'String'
                }
            }
        )
    else:
        logger.info("[send_to_queue]: Final data being sent to queue: {}".format(data))
        sqs_client.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps(data),
            MessageAttributes={
                'panw-fw-nlb-msg': {
                    'StringValue': '1000',
                    'DataType': 'String'
                }
            }
        )


def assume_role_and_send_to_queue(role_arn, data, queue_url):
    """

    :param data:
    :return:
    """

    assumedRoleObject = sts_client.assume_role(
        RoleArn=role_arn,
        RoleSessionName="AssumeRoleSession1"
    )

    # From the response that contains the assumed role, get the temporary
    # credentials that can be used to make subsequent API calls
    credentials = assumedRoleObject['Credentials']

    sqs_resource = boto3.client(
        'sqs',
        aws_access_key_id=credentials['AccessKeyId'],
        aws_secret_access_key=credentials['SecretAccessKey'],
        aws_session_token=credentials['SessionToken']
    )

    send_to_queue(data, queue_url, sqs_resource)


def modify_message_data(az_info):
    """
    Changes the az_info object keys from SubnetId to SUBNET-ID and ZoneName to ZONE-NAME

    :param az_info:
    :return:
    """

    logger.info("[modify_message_data]: Input az_info: {}".format(az_info))
    try:
        az_data = []
        for _az in az_info:
            subnet_id = _az.pop('SubnetId')
            zone_name = _az.pop('ZoneName')

            _az['SUBNET-ID'] = subnet_id
            _az['ZONE-NAME'] = zone_name
            az_data.append(_az)

        logger.info("[modify_message_data] Modified message data: {}".format(az_data))
        return az_data
    except Exception as e:
        logger.info(e)
    logger.info("Returning from modify_message_data")
    return None


def parse_and_create_del_alb_data(ilb_response):
    return {
        'MSG-TYPE': 'DEL-ALB',
        'DNS-NAME': ilb_response
    }


def parse_and_create_del_nlb_data(ilb_response, vpc_endpoint_service_name):
    return {
        'MSG-TYPE': 'DEL-NLB',
        'DNS-NAME': ilb_response,
        'VPC-ENDPOINT-SERVICE-NAME': vpc_endpoint_service_name
    }


def parse_and_create_add_nlb_data(ilb_response, vpc_endpoint_service_name):
    """
    Example Message:
    {
      "AVAIL-ZONES": [
        {
          "LoadBalancerAddresses": [
            {}
          ],
          "SUBNET-CIDR": "172.32.0.0/24",
          "SUBNET-ID": "subnet-0b901425",
          "ZONE-NAME": "us-east-1a"
        },
        {
          "LoadBalancerAddresses": [
            {}
          ],
          "SUBNET-CIDR": "172.32.1.0/24",
          "SUBNET-ID": "subnet-4a5a1300",
          "ZONE-NAME": "us-east-1b"
        }
      ],
      "MSG-TYPE": "ADD-NLB",
      "DNS-NAME": "prot-ilb-b7aaa076742392b2.elb.us-east-1.amazonaws.com",
      "NLB-NAME": "prot-ilb",
      "NLB-ARN": "arn:aws:elasticloadbalancing:us-east-1:441384421500:loadbalancer/net/prot-ilb/b7aaa076742392b2",
      "VPC-ENDPOINT-SERVICE-ID": "vpce-svc-0e3558640fb9b6d57",
      "VPC-ID": "vpc-c173b8bb"
    }
    """
    load_balancers = ilb_response.get('LoadBalancers')
    if len(load_balancers) == 0:
        logger.error('[parse_and_create_add_nlb_data]: No load balancers found in ilb_response\n{}'.format(ilb_response))
        return {}
    ilb = load_balancers[0]
    dns_name = ilb.get('DNSName', None)
    ilb_name = ilb.get('LoadBalancerName')
    az_info = ilb.get('AvailabilityZones')

    logger.info("[parse_and_create_add_nlb_data]: Original AZ data: {}".format(az_info))
    updated_az_data = modify_message_data(az_info)
    logger.info("[parse_and_create_add_nlb_data]: Updated AZ data: {}".format(updated_az_data))

    subnets = get_subnet_info(updated_az_data)['Subnets']

    # Add vpc subnet cidrs to az info
    for az in updated_az_data:
        for subnet in subnets:
            if subnet['SubnetId'] == az['SUBNET-ID']:
                az['SUBNET-CIDR'] = subnet['CidrBlock']
                logger.info('[parse_and_create_add_nlb_data] Adding SUBNET-CIDR {} to AVAIL-ZONES'.format(subnet['CidrBlock']))

    vpc_id = ilb.get('VpcId', None)
    ilb_arn = ilb.get('LoadBalancerArn', None)
    msg_data = {
        'MSG-TYPE': 'ADD-NLB',
        'AVAIL-ZONES': updated_az_data,
        'DNS-NAME': dns_name,
        'VPC-ID': vpc_id,
        'VPC-ENDPOINT-SERVICE-NAME': vpc_endpoint_service_name,
        'NLB-NAME': ilb_name,
        'NLB-ARN': ilb_arn
    }
    return msg_data


def parse_and_create_add_alb_data(ilb_response, vpc_peer_connection):
    """
    Constructs an ADD-ALB message to send to the SQS queue.
    If not cross vpc, vpc_peer_connection should be the string "None"


    """
    load_balancers = ilb_response.get('LoadBalancers')
    if len(load_balancers) == 0:
        logger.error('[parse_and_create_add_alb_data]: No load balancers found in ilb_response\n{}'.format(ilb_response))
        return {}
    ilb = load_balancers[0]
    dns_name = ilb.get('DNSName', None)
    ilb_name = ilb.get('LoadBalancerName')
    az_info = ilb.get('AvailabilityZones')

    logger.info("[parse_and_create_add_alb_data]: Original AZ data: {}".format(az_info))
    updated_az_data = modify_message_data(az_info)
    logger.info("[parse_and_create_add_alb_data]: Updated AZ data: {}".format(updated_az_data))

    subnets = get_subnet_info(updated_az_data)['Subnets']

    # Add vpc subnet cidrs to az info
    for az in updated_az_data:
        for subnet in subnets:
            if subnet['SubnetId'] == az['SUBNET-ID']:
                az['SUBNET-CIDR'] = subnet['CidrBlock']
                logger.info('[parse_and_create_add_alb_data] Adding SUBNET-CIDR {} to AVAIL-ZONES'.format(subnet['CidrBlock']))

    vpc_id = ilb.get('VpcId', None)

    # Retrieve the VPC CIDR and pass it; in the cross account case, we cannot look up the CIDR in the hub.
    response = ec2_client.describe_vpcs(VpcIds=[vpc_id])
    for r in response['Vpcs']:
        vpc_cidr= r['CidrBlock']

    ilb_arn = ilb.get('LoadBalancerArn', None)
    msg_data = {
        'MSG-TYPE': 'ADD-ALB',
        'AVAIL-ZONES': updated_az_data,
        'DNS-NAME': dns_name,
        'VPC-ID': vpc_id,
        'VPC-CIDR': vpc_cidr,
        'VPC-PEERCONN-ID': vpc_peer_connection,
        'ALB-NAME': ilb_name,
        'ALB-ARN': ilb_arn
    }
    return msg_data


def parse_and_create_ilb_data(msg_operation, ilb_response, vpc_peer_connection, vpc_endpoint_service_name, initial):
    """
    Constructs messages to send to the SQS queue

    :param msg_operation:
    :param ilb_response:
    :param vpc_peer_connection:
    :param initial:
    """

    msg_data = None

    if msg_operation == 'DEL-NLB':
        logger.info('[parse_and_create_ilb_data] Creating DEL-NLB message')
        msg_data = parse_and_create_del_nlb_data(ilb_response, vpc_endpoint_service_name)
    elif msg_operation == 'DEL-ALB':
        logger.info('[parse_and_create_ilb_data] Creating DEL-ALB message')
        msg_data = parse_and_create_del_alb_data(ilb_response)
    elif msg_operation == 'ADD-NLB':
        logger.info('[parse_and_create_ilb_data] Creating ADD-NLB message')
        msg_data = parse_and_create_add_nlb_data(ilb_response, vpc_endpoint_service_name)
    elif msg_operation == 'ADD-ALB':
        logger.info('[parse_and_create_ilb_data] Creating ADD-ALB message')
        msg_data = parse_and_create_add_alb_data(ilb_response, vpc_peer_connection)

    logger.info("[parse_and_create_ilb_data] Message to send to queue: {}".format(msg_data))
    return msg_data


def handle_ilb_delete(ilb_dns, ilb_type, queue_url, role_arn, vpc_endpoint_service_name):
    """
    This method handles the delete workflow
    associated with the case when an ILB has
    been deleted.

    This method performs the following actions:
    1. Extract ILB information from the DB.
    2. Construct and send a NLB-DEL/ALB-DEL message to SQS.

    :param ilb_arn:
    :return:
    """

    delete_message = parse_and_create_ilb_data(msg_operation='DEL-{}'.format(ilb_type),
                                               ilb_response=ilb_dns,
                                               vpc_peer_connection=None,
                                               vpc_endpoint_service_name=vpc_endpoint_service_name,
                                               initial=False)
    if role_arn:
        logger.info('[handle_ilb_delete] Role ARN specified. Calling handle_')
        assume_role_and_send_to_queue(role_arn, delete_message, queue_url)
    else:
        logger.info('[handle_ilb_delete] Send to queue in same account.')
        send_to_queue(delete_message, queue_url, None)


def handle_ilb_add(ilb_response,
                   ilb_type,
                   is_cross_vpc,
                   vpc_peer_connection,
                   vpc_endpoint_service_name,
                   ilb_route_table,
                   queue_url,
                   role_arn):
    """
    This method handles the add ilb workflow
    to identify a new ILB and publish the information
    out to a queue.

    :param ilb_arn:
    :param ilb_name:
    :return:
    """
    logger.info("****************** handle ilb add  START **************")
    logger.info("[handle_ilb_add] ILB details: {}".format(ilb_response))

    logger.info("Retrieve subnet details")

    add_message = parse_and_create_ilb_data(msg_operation='ADD-{}'.format(ilb_type),
                                            ilb_response=ilb_response,
                                            vpc_peer_connection=vpc_peer_connection,
                                            vpc_endpoint_service_name=vpc_endpoint_service_name,
                                            initial=False)

    ilb_dns = add_message.get('DNS-NAME', None)
    logger.info("ilb dns name: {}".format(ilb_dns))

    if role_arn:
        logger.info("[handle_ilb_add] Role ARN specified. Calling handle_")
        assume_role_and_send_to_queue(role_arn, add_message, queue_url)
    else:
        logger.info("[hanlde_ilb_add] Send to queue in same account.")
        send_to_queue(add_message, queue_url, None)
    logger.info("****************** handle ilb add  END **************")


def add_ilb_route_table_entries(ilb_route_table, target_cidrs, vpc_peer_connection):
    """
    This method adds route table entries to the ilb route table
    in order to direct traffic accross the vpc peering connection

    :param: ilb_route_table
    :param: target_cidrs
    :param: vpc_peer_connection
    :return:
    """
    logger.info('****************** add ilb route table entries  START **************')
    for target_cidr in target_cidrs:
        create_vpcpeer_routetable_entry(DestinationCidrBlock=target_cidr,
                                        RouteTableId=ilb_route_table,
                                        VpcPeeringConnectionId=vpc_peer_connection)
    logger.info("****************** add ilb route table entries  END **************")


def delete_ilb_route_table_entries(ilb_route_table, target_cidrs):
    """
    This method deletes route table entries from the ilb route table

    :param: ilb_route_table
    :param: target_cidrs
    :return:
    """
    logger.info('****************** delete ilb route table entries  START **************')
    for target_cidr in target_cidrs:
        delete_vpcpeer_routetable_entry(DestinationCidrBlock=target_cidr,
                                        RouteTableId=ilb_route_table)
    logger.info("****************** delete ilb route table entries  END **************")


def add_ilb_endpoint_service_principal(vpc_endpoint_service_id, principal_arn):
    logger.info('****************** add ilb endpoint service permissions  START **************')
    response = ec2_client.modify_vpc_endpoint_service_permissions(
        ServiceId=vpc_endpoint_service_id,
        AddAllowedPrincipals=[principal_arn]
    )
    logger.info('[add_ilb_endpoint_service_principal] RESPONSE: {}'.format(response))
    logger.info('****************** add ilb endpoint service permissions  END **************')


def delete_ilb_endpoint_service_principal(vpc_endpoint_service_id, principal_arn):
    logger.info('****************** add ilb endpoint service permissions  START **************')
    response = ec2_client.modify_vpc_endpoint_service_permissions(
        ServiceId=vpc_endpoint_service_id,
        RemoveAllowedPrincipals=[principal_arn]
    )
    logger.info('[delete_ilb_endpoint_service_principal] RESPONSE: {}'.format(response))
    logger.info('****************** add ilb endpoint service permissions  END **************')


def reject_ilb_endpoint_service_connections(vpc_endpoint_service_id):
    """
    Obtains a list of all enpoints connected to the given endpoint service and rejects all of them.
    """
    logger.info('****************** reject ilb endpoint service connections  START **************')
    response = ec2_client.describe_vpc_endpoint_connections(Filters=[{
        'Name': 'service-id',
        'Values': [vpc_endpoint_service_id]
    }])
    # Line below converts the array of connection objects to a list of endpoint ids
    endpointIds = map(lambda connection: connection['VpcEndpointId'], response['VpcEndpointConnections'])
    response = ec2_client.reject_vpc_endpoint_connections(ServiceId=vpc_endpoint_service_id,
                                                          VpcEndpointIds=endpointIds)
    logger.info('****************** reject ilb endpoint service connections  END **************')


def send_response(event, context, responseStatus):
    """

    :param event:
    :param context:
    :param responseStatus:
    :return:
    """

    r = responseStatus.split(":")
    logger.info(r)
    rs = str(r[0])
    reason = ""
    if len(r) > 1:
        reason = str(r[1])
    else:
        reason = 'See the details in CloudWatch Log Stream.'
    logger.info('send_response() to stack -- responseStatus: ' + str(rs) + ' Reason: ' + str(reason))
    response = {
        'Status': str(rs),
        'Reason': str(reason),
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'PhysicalResourceId': event['LogicalResourceId']
    }
    logger.info('RESPONSE: ' + json.dumps(response))
    parsed_url = urlparse(event['ResponseURL'])
    if (parsed_url.hostname == ''):
        logger.info('[ERROR]: Parsed URL is invalid...')
        return 'false'

    logger.info('[INFO]: Sending Response...')
    try:
        with closing(HTTPSConnection(parsed_url.hostname)) as connection:
            connection.request("PUT", parsed_url.path + "?" + parsed_url.query, json.dumps(response))
            response = connection.getresponse()
            if response.status != 200:
                logger.info('[ERROR]: Received non 200 response when sending response to cloudformation')
                logger.info('[RESPONSE]: ' + response.msg)
                return 'false'
            else:
                logger.info('[INFO]: Got good response')

    except Exception:
        logger.info('[ERROR]: Got ERROR in sending response...')
        return 'false'
    finally:

        connection.close()
        return 'true'


def handle_stack_create(event, context):

    logger.info(event['ResourceProperties'])
    stackname = event['ResourceProperties']['StackName']
    region = event['ResourceProperties']['Region']
    VpcId = event['ResourceProperties']['VpcId']
    SvcName = event['ResourceProperties']['SvcName']
    GwlbeSubnetIds = event['ResourceProperties']['GwlbeSubnetIds']
    TGWAttId = event['ResourceProperties']['TGWAttId']
    GwlbeSubnetIds=str(fix_unicode(GwlbeSubnetIds))
    GwlbeSubnetIds=fix_subnets(GwlbeSubnetIds)
    Gwlbe_subnetIds = GwlbeSubnetIds.split(",")
    logger.info(Gwlbe_subnetIds)
    ALBRouteTableIds = event['ResourceProperties']['ALBRouteTableIds']
    ALBRouteTableIds=str(fix_unicode(ALBRouteTableIds))
    ALBRouteTableIds=fix_subnets(ALBRouteTableIds)
    ALB_rtIds = ALBRouteTableIds.split(",")
    logger.info(ALB_rtIds)
    IGW = event['ResourceProperties']['IGW']
    ALBCidr = event['ResourceProperties']['ALBCIDR']
    ALBCidr=str(fix_unicode(ALBCidr))
    ALBCidr=fix_subnets(ALBCidr)
    ALB_Cidrs = ALBCidr.split(',')
    logger.info(ALB_Cidrs)


    try:

        ## create dynamodb
        create_ibd_rt_table(stackname, region)

        ## create inbound route table
        res = ec2_client.create_route_table(
            VpcId = VpcId,
        )
        Inbound_rtId = res['RouteTable']['RouteTableId']

        ## associate inbound route table
        logger.info("Associate inbound route table to IGW")
        res = ec2_client.associate_route_table(
            RouteTableId=Inbound_rtId,
            GatewayId=IGW
        )
        associate_id = res['AssociationId']
        ## write into dynamodb
        ibd_rt_table_add_entry(stackname, region, Inbound_rtId, associate_id)
        ## create gwlb endpoint
        logger.info("Creating GWLB endpoint table for stack %s" % stackname)
        create_gwlb_endpoint_table(stackname, region)
        for idx in range(len(Gwlbe_subnetIds)):
            logger.info("Create GWLB endpoint")
            gwlbe_subnetId = Gwlbe_subnetIds[idx]
            res = gwlbe_client.create_vpc_endpoint(VpcEndpointType='GatewayLoadBalancer',VpcId=VpcId,SubnetIds=[gwlbe_subnetId],ServiceName=SvcName)
            logger.info(res)
            GwlbeENIIds = res['VpcEndpoint']['NetworkInterfaceIds']
            GwlbeId = res['VpcEndpoint']['VpcEndpointId']
            ### write gwlb endpoint related information into DynamoDB table
            if gwlb_endpoint_table_add_entry(stackname, region, GwlbeId, GwlbeENIIds[0]) == False:
                logger.error("Failed to add GWLB endpoint entry for endpoint %s" % GwlbeId)
                return
            else:
                logger.info("Added entry for GWLB endpoint %s" % GwlbeId)
            cnt = 0
            while cnt < 6:
                res = gwlbe_client.describe_vpc_endpoints(
                    VpcEndpointIds=[
                        GwlbeId,
                    ]
                )
                logger.info(res)
                state = res['VpcEndpoints'][0]['State']
                logger.info(state)
                if state != 'available':
                    cnt += 1
                    sleep(30)
                else:
                    break
            if cnt >= 6:
                logger.error("GWLB endpoint failed to be stable after creation")
                return
            ##edit inbound route table

            logger.info("Creating route in inbound route table Az%d"%(idx+1))
            logger.info(ALB_Cidrs[idx])
            logger.info(Inbound_rtId)
            response = ec2_client.create_route(
                DestinationCidrBlock=ALB_Cidrs[idx],
                NetworkInterfaceId=GwlbeENIIds[0],
                RouteTableId=Inbound_rtId
            )
            ##edit ALB route table
            logger.info("Creating route in ALB route table Az%d"%(idx+1))
            response = ec2_client.create_route(
                DestinationCidrBlock="0.0.0.0/0",
                NetworkInterfaceId=GwlbeENIIds[0],
                RouteTableId=ALB_rtIds[idx]
            )

        send_response(event, context, "SUCCESS")
        logger.info("Successfully completed the lambda function deployment and execution.")
    except Exception as e:
        logger.info(e)
        logger.info("Failure encountered during lambda function deployment and execution.")
        send_response(event, context, "FAILED")
    finally:
        logger.info("Returning from lambda function deployment and execution.")

def handle_stack_delete(event, context):
    """

    :param event:
    :param context:
    :return:
    """

    logger.info(event['ResourceProperties'])
    stackname = event['ResourceProperties']['StackName']
    region = event['ResourceProperties']['Region']
    VpcId = event['ResourceProperties']['VpcId']
    SvcName = event['ResourceProperties']['SvcName']
    GwlbeSubnetIds = event['ResourceProperties']['GwlbeSubnetIds']
    GwlbeSubnetIds=str(fix_unicode(GwlbeSubnetIds))
    GwlbeSubnetIds=fix_subnets(GwlbeSubnetIds)
    Gwlbe_subnetIds = GwlbeSubnetIds.split(",")
    logger.info(Gwlbe_subnetIds)
    ALBRouteTableIds = event['ResourceProperties']['ALBRouteTableIds']
    ALBRouteTableIds=str(fix_unicode(ALBRouteTableIds))
    ALBRouteTableIds=fix_subnets(ALBRouteTableIds)
    ALB_rtIds = ALBRouteTableIds.split(",")
    logger.info(ALB_rtIds)
    IGW = event['ResourceProperties']['IGW']
    ALBCidr = event['ResourceProperties']['ALBCIDR']
    ALBCidr=str(fix_unicode(ALBCidr))
    ALBCidr=fix_subnets(ALBCidr)
    ALB_Cidrs = ALBCidr.split(',')
    logger.info(ALB_Cidrs)


    ## delete ALB route
    for rtId in ALB_rtIds:
        try:
            res = ec2_client.delete_route(
                DestinationCidrBlock='0.0.0.0/0',
                RouteTableId=rtId
            )
            logger.info(res)
        except Exception as e:
            logger.error("Fail to delete route in ALB route table %s - %s"%(rtId,str(e)))

    ## get entry from rt table dynamodb
    res = idb_rt_table_get_entry(stackname, region)
    if not res:
        logger.error("Failed to get inbound table entry for stack %s" % stackname)
        return
    Inbound_rtId = res['RouteTableId']
    Association_Id = res['AssociationId']

    logger.info("Deleting route in inbound route table...")
    for dest in ALB_Cidrs:
        try:
            res = ec2_client.delete_route(
                DestinationCidrBlock=dest,
                RouteTableId=Inbound_rtId
            )
            logger.info(res)
        except Exception as e:
            logger.error("Fail to delete route %s in inbound route table %s - %s" % (dest,Inbound_rtId, str(e)))

    ## delete inbound route
    logger.info("Deleting inbound route table association...")
    try:
        res = ec2_client.disassociate_route_table(
            AssociationId=Association_Id,
        )
    except Exception as e:
        logger.error("Fail to disassociate inbound route table %s - %s" % (Inbound_rtId, str(e)))


    logger.info("Deleting inbound route table...")
    try:
        res = ec2_client.delete_route_table(
            RouteTableId=Inbound_rtId,
        )
        logger.info(res)
    except Exception as e:
        logger.error("Fail to delete inbound route table %s - %s" % (Inbound_rtId, str(e)))

    ## delete gwlbe
    res = gwlb_endpoint_table_get_entry(stackname, region)
    if not res:
        logger.error("Failed to get GWLB endpoint entry for stack %s" % stackname)
        return

    for entry in res:
        try:
            GwlbeEndpointId = entry['GwlbeEndpointId']
            logger.info("Deleting GWLB endpoint")
            res = gwlbe_client.delete_vpc_endpoints(VpcEndpointIds=[GwlbeEndpointId])
            logger.info(res)
        except Exception as e:
            logger.exception('failed to delete GWLB endpoint %s - %s'%(GwlbeEndpointId,str(e)))

    table_name = get_gwlb_endpoint_table_name(stackname, region)
    delete_table(table_name)

    table_name = get_ibd_rt_table_name(stackname, region)
    delete_table(table_name)

    send_response(event, context, "SUCCESS")

def gwlb_deploy_handler(event, context):
    """
    This method serves and the first point of contact
    for the AWS Cloud Formation Custom Resource. It gets invoked
    when the custom resource is executed by the Cloud Formation Service.

    The method serves the following
    :param event:
    :param context:
    :return:
    """

    logger.info("Called with event: {}".format(event))
    if event['RequestType'] == 'Delete':
        handle_stack_delete(event, context)
    elif event['RequestType'] == 'Create':
        handle_stack_create(event, context)
